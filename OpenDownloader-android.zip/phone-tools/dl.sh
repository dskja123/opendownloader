#!/usr/bin/env bash
# 通用直链下载 · Termux 版
# 只下载你手动填入、且有权保存的公开 HTTPS 直链。
# 不带 Cookie / Referer / Authorization，不做任何站点解析。
#
# 首次使用：
#   pkg install curl
#   termux-setup-storage          # 弹窗授权后重开 Termux
#   chmod +x dl.sh
#   ./dl.sh https://example.com/file.zip
#
# 后台跑（配合 termux-wake-lock 防止休眠中断）：
#   termux-wake-lock && nohup ./dl.sh "https://..." > dl.log 2>&1 &

set -euo pipefail

URL="${1:-}"
case "$URL" in
  https://*) ;;
  *)
    if [ -z "$URL" ]; then
      echo "用法：./dl.sh <https://...>"
    else
      echo "只接受 https:// 开头的公开直链"
    fi
    exit 1
    ;;
esac

HOST=$(printf '%s' "$URL" | sed -E 's#^https://([^/?#]+).*#\1#')
if [ -z "$HOST" ] || [ "$HOST" = "$URL" ]; then
  echo "链接缺少有效域名"
  exit 1
fi

OUT_DIR="$HOME/storage/downloads/OpenDownloader"
if ! mkdir -p "$OUT_DIR" 2>/dev/null; then
  echo "找不到公共下载目录，请先运行 termux-setup-storage 并授权"
  exit 1
fi

# 从 URL 末段推断文件名，清洗非法字符与路径穿越
NAME=$(basename "${URL%%\?*}")
NAME=$(printf '%s' "$NAME" | tr -c 'A-Za-z0-9._-' '_')
NAME=$(printf '%s' "$NAME" | sed 's/\.\./_/g; s/^\.*//')
[ -n "$NAME" ] || NAME="download_$(date +%s).bin"
[ "${#NAME}" -gt 80 ] && NAME="${NAME:0:80}"
TARGET="$OUT_DIR/$NAME"

echo "保存到：$TARGET"
echo "提示：curl 自带进度条；中断后原样重跑可尝试续传。"
echo

# 刻意不加 -H / -b / -e：不带任何请求头
if curl -L --fail --retry 2 --retry-delay 2 --progress-bar \
        -C - -o "$TARGET" "$URL"; then
  echo
  echo "完成：$TARGET"
else
  rc=$?
  echo
  echo "下载未完成（curl 退出码 $rc）。可能是链接需要登录、服务器不支持续传，或网络中断。" >&2
  exit "$rc"
fi

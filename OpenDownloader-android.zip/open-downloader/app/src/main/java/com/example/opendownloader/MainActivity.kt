package com.example.opendownloader

import android.Manifest
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.URLDecoder
import java.util.Locale

/**
 * 教学用「通用直链下载器」。
 *
 * 边界：只把用户手填的公开 HTTPS 直链交给系统 DownloadManager。
 * 不解析任何站点、不注入 Cookie / Referer / 签名、不处理鉴权或分片流。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var startButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var downloadId: Long = -1L
    private var pendingRawUrl: String? = null
    private var polling = false
    private var receiverRegistered = false

    private val requestLegacyStorage =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val raw = pendingRawUrl
            pendingRawUrl = null
            if (raw != null && granted) {
                enqueueDownload(raw)
            } else {
                startButton.isEnabled = true
                Toast.makeText(this, R.string.toast_permission_denied, Toast.LENGTH_LONG).show()
            }
        }

    private val completeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != downloadId) return
            stopPolling()
            progressBar.progress = 100
            statusText.text = getString(R.string.status_done)
            startButton.isEnabled = true
            Toast.makeText(this@MainActivity, R.string.toast_done, Toast.LENGTH_SHORT).show()
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!polling) return
            var finished = false
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val cursor = dm.query(DownloadManager.Query().setFilterById(downloadId))
            cursor?.use { c ->
                if (c.moveToFirst()) {
                    val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val soFar = c.getLong(
                        c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    )
                    val total = c.getLong(
                        c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    )
                    val percent = if (total > 0) {
                        (soFar * 100 / total).toInt().coerceIn(0, 100)
                    } else {
                        0
                    }
                    progressBar.progress = percent

                    when (status) {
                        DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING -> {
                            statusText.text =
                                getString(R.string.status_progress, percent, humanSize(soFar))
                        }

                        DownloadManager.STATUS_SUCCESSFUL -> {
                            progressBar.progress = 100
                            statusText.text = getString(R.string.status_done)
                            startButton.isEnabled = true
                            finished = true
                        }

                        DownloadManager.STATUS_FAILED -> {
                            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            statusText.text = getString(R.string.status_failed, reasonText(reason))
                            startButton.isEnabled = true
                            finished = true
                        }
                    }
                }
            }
            if (finished) {
                stopPolling()
            } else {
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        startButton = findViewById(R.id.startButton)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)

        savedInstanceState?.let {
            downloadId = it.getLong(KEY_DOWNLOAD_ID, -1L)
            pendingRawUrl = it.getString(KEY_PENDING_URL)
        }

        startButton.setOnClickListener { startDownload() }
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this,
                completeReceiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
        if (downloadId != -1L) startPolling()
    }

    override fun onStop() {
        stopPolling()
        if (receiverRegistered) {
            unregisterReceiver(completeReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(KEY_DOWNLOAD_ID, downloadId)
        pendingRawUrl?.let { outState.putString(KEY_PENDING_URL, it) }
    }

    private fun startDownload() {
        val raw = urlInput.text.toString().trim()
        val uri = Uri.parse(raw)

        // 只接受公开 HTTPS 直链：拒绝明文 HTTP、非 http(s) scheme、无域名输入
        if (!raw.startsWith("https://", ignoreCase = true) ||
            uri.scheme?.equals("https", ignoreCase = true) != true ||
            uri.host.isNullOrBlank()
        ) {
            urlInput.error = getString(R.string.error_url)
            return
        }

        // Android 9 及以下写公共下载目录需要运行时权限；Android 10+ 由系统下载服务代写
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingRawUrl = raw
            requestLegacyStorage.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }

        enqueueDownload(raw)
    }

    private fun enqueueDownload(raw: String) {
        val fileName = safeFileName(raw)
        val request = DownloadManager.Request(Uri.parse(raw)).apply {
            setTitle(fileName)
            setDescription(getString(R.string.dm_description))
            setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            setAllowedNetworkTypes(
                DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
            )
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "$SUB_DIR/$fileName"
            )
            // 刻意不调用 addRequestHeader：不带 Cookie、Referer、Authorization 或任何签名参数
        }

        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        downloadId = dm.enqueue(request)

        startButton.isEnabled = false
        progressBar.progress = 0
        statusText.text = getString(R.string.status_pending)
        startPolling()
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        handler.post(pollRunnable)
    }

    private fun stopPolling() {
        polling = false
        handler.removeCallbacks(pollRunnable)
    }

    /** 从 URL 末段推断文件名，并清洗掉路径穿越与非法字符 */
    private fun safeFileName(raw: String): String {
        val segment = Uri.parse(raw).lastPathSegment?.substringBefore('?').orEmpty()
        val decoded = try {
            URLDecoder.decode(segment, "UTF-8")
        } catch (e: Exception) {
            segment
        }
        var name = decoded.map { ch ->
            if (ch.isLetterOrDigit() || ch == '.' || ch == '-' || ch == '_' || ch == ' ') {
                ch
            } else {
                '_'
            }
        }.joinToString("")
        name = name.replace("..", "_").trim().trim('.')
        if (name.length > 80) name = name.take(80)
        if (name.isBlank()) name = "download_${System.currentTimeMillis()}.bin"
        return name
    }

    private fun humanSize(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L ->
            String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))

        else -> String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun reasonText(reason: Int): String = when (reason) {
        DownloadManager.ERROR_CANNOT_RESUME -> "无法续传"
        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "存储设备不可用"
        DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "同名文件已存在"
        DownloadManager.ERROR_FILE_ERROR -> "文件写入失败"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "HTTP 数据错误"
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "存储空间不足"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "重定向次数过多"
        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "服务器返回未处理的状态码"
        DownloadManager.ERROR_UNKNOWN -> "未知错误"
        else -> "错误码 $reason"
    }

    private companion object {
        const val SUB_DIR = "OpenDownloader"
        const val POLL_INTERVAL_MS = 500L
        const val KEY_DOWNLOAD_ID = "key_download_id"
        const val KEY_PENDING_URL = "key_pending_url"
    }
}

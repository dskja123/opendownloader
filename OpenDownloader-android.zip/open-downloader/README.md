# 通用直链下载器（Android 教学工程）

一个最小可运行的 Android 下载器：把你**手动填入的公开 HTTPS 直链**交给系统 `DownloadManager`，显示进度，文件落到「下载 / OpenDownloader」目录。

## 它不做什么

- 不解析任何网站、不提取视频地址、不处理 m3u8 / DASH 分片
- 不附带 Cookie、Referer、Authorization 或签名参数（代码里刻意没有 `addRequestHeader`）
- 不绕过登录、会员、防盗链或任何访问控制
- 只接受 `https://` 开头的输入，明文 HTTP 在 Manifest 里也被 `usesCleartextTraffic="false"` 关掉

所以像「B站视频页链接」这类**不是普通文件直链**的地址，填进去不会得到视频——这是预期行为，不是 bug。请只下载你自己有权保存的内容。

## 已实现

| 能力 | 做法 |
| --- | --- |
| 下载与断点续传 | 系统 `DownloadManager`，后台、重启、省电策略由系统托管 |
| 进度与状态 | 每 500ms 查询 `DownloadManager.Query`，更新进度条和文字 |
| 完成通知 | 系统下载服务自带通知 + `ACTION_DOWNLOAD_COMPLETE` 广播 |
| 旧系统权限 | 仅 Android 9 及以下申请 `WRITE_EXTERNAL_STORAGE`（`maxSdkVersion=28`） |
| 文件名安全 | 从 URL 末段推断，过滤非法字符与 `..` 路径穿越 |
| 旋转屏恢复 | `onSaveInstanceState` 保存 downloadId |

## 环境

- Android Studio Koala（或更新版）
- JDK 17
- Android SDK Platform 34、Build-Tools 34
- 最低支持 Android 8.0（API 26），目标 API 34

版本组合 `AGP 8.5.2 + Gradle 8.7 + Kotlin 1.9.24 + JDK 17 + compileSdk 34` 已有实测跑通的先例；若 Sync 时出现 Kotlin 插件的版本废弃警告，把根 `build.gradle` 里的 Kotlin 版本改成 `2.1.0` 即可，AGP 和 Gradle 不用动。

## 构建 APK

**方式 A：Android Studio（推荐）**

1. `File → Open`，选择本目录 `open-downloader`
2. 等待 Gradle Sync 完成（首次会下载 AGP 8.5.2 / Kotlin 1.9.24 / Gradle 8.7）
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`

**方式 B：命令行**

工程已自带完整的 Gradle Wrapper（`gradlew` + `gradle-wrapper.jar`），不需要本机预装 Gradle：

```bash
cd open-downloader
chmod +x gradlew
./gradlew assembleDebug
```

产物同样是 `app/build/outputs/apk/debug/app-debug.apk`。

安装到手机：

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 没有电脑：手机上的办法

### A. 连 APK 都不装：Termux 直接下直链（最省事）

工程的教学目的本来就是「把公开 HTTPS 直链下载到本机」，这件事在手机上用 Termux 一行就能做，不需要编译：

1. 装 **Termux**（建议从 F-Droid 或官方 GitHub Release 装，别用应用商店的旧版）
2. `pkg install curl`，再执行 `termux-setup-storage` 并在弹窗里授权
3. 把压缩包里 `phone-tools/dl.sh` 放到 Termux 家目录，`chmod +x dl.sh`
4. `./dl.sh https://example.com/file.zip`

脚本会校验 `https`、清洗文件名、用 curl 显示进度并尝试断点续传，文件落到「下载 / OpenDownloader」。同样不带任何请求头、不做站点解析。只想立刻用的话，连脚本都不必建：

```bash
curl -L --progress-bar -o ~/storage/downloads/文件名 https://example.com/file.zip
```

### B. 想要 APK 成品：手机浏览器 + GitHub Actions 云编译

编译在云端 Linux 上跑，手机只负责上传和下载。压缩包根目录的 `build-apk.yml` 就是现成配置。

1. 手机浏览器登录 GitHub → 新建 **Public** 仓库（例如 `opendownloader`）
   - 如果页面没有 `Add file` / `Actions` 这些按钮，先在浏览器菜单里选「请求桌面网站」，GitHub 移动版网页没有上传入口
2. `Add file → Upload files`，从手机「下载」目录选本压缩包（`.zip`，约 60KB），`Commit changes`
   - 文件名保持原样即可，workflow 用通配符找根目录的 zip；仓库根目录只放这一个 zip
3. `Add file → Create new file`，文件名填 `.github/workflows/build.yml`（带斜杠会自动建目录），把 `build-apk.yml` 的内容**原样粘贴**，`Commit changes`
4. 第 2 步那次提交不会触发编译（当时还没有 workflow）；第 3 步提交会自动跑。也可到 `Actions → build → Run workflow` 手动重跑
5. 跑完在该次运行页底部 **Artifacts** 下载 `apk`（GitHub 会再包一层 zip），解压得到 `app-debug.apk`
6. 用手机文件管理器点开 APK 安装，按提示允许「安装未知来源应用」

debug 包由 Gradle 自动用调试密钥签名，可直接安装。GitHub Actions 免费额度足够跑很多次，单次约 3–6 分钟。

### C. 手机上本地编译（硬核）

Termux 里直接跑 AGP 8.x 会遇到 aapt2 只有 x86_64 二进制的架构问题；AIDE 之类的手机 IDE 也吃不下 Kotlin + AndroidX + AGP 8.x 这套组合。若确实想本地编译，需要把工程改写成纯 Java + 老式构建的版本，可以单独说一声。

## 代码索引

```
压缩包根目录/
├── open-downloader/                      完整 Android 工程
│   ├── gradlew + gradle/wrapper/*.jar    Gradle Wrapper，开箱即构建
│   ├── app/src/main/AndroidManifest.xml  权限、明文流量开关、Activity 声明
│   ├── app/src/main/java/.../MainActivity.kt   全部逻辑
│   ├── app/src/main/res/                 布局与字符串
│   └── README.md                         含「没有电脑：手机上的办法」
├── build-apk.yml                         GitHub Actions 云编译配置
└── phone-tools/dl.sh                     Termux 直链下载脚本
```

关键几行：

- `startDownload()`：只放行 `https` + 有效域名的输入
- `enqueueDownload()`：构造 `DownloadManager.Request`，注意里面**没有任何请求头**
- `pollRunnable`：读 `COLUMN_BYTES_DOWNLOADED_SO_FAR` / `COLUMN_TOTAL_SIZE_BYTES`
- `safeFileName()`：把 URL 末段清洗成安全文件名

## 常见问题

- **下载了但找不到文件**：用系统「文件 / 下载」应用看 `下载 / OpenDownloader`；Android 10+ 由系统下载服务写入，第三方文件管理器可能看不到。
- **一直显示「已提交」**：服务器没返回 `Content-Length` 时总大小为 -1，进度条会停在 0，完成后会正常跳到完成态。
- **提示存储权限**：只会出现在 Android 9 及以下，授权后会自动继续入队。

## 可以继续加的练习

多任务队列与历史列表、`ACTION_VIEW` 打开已完成文件、按 Content-Type 推断扩展名、下载前 HEAD 探测大小、使用 `WorkManager` 管理批量任务。这些都不需要碰任何站点解析逻辑。

> 合规提醒：本工程仅用于学习 Android 下载框架。请只保存你拥有权利或已获授权的内容，不要用于批量抓取、绕过访问控制或二次分发。
